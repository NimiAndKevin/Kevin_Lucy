import pyttsx3
import speech_recognition as sr
import webbrowser
import wikipedia
import requests
import json
import random
import datetime
import pywhatkit

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Initialize the speech recognizer
recognizer = sr.Recognizer()

# Define a variable to store the current status
user_status = "I'm doing well."

# Function to speak a given text
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function to listen for a voice command
def listen_for_command():
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
    try:
        return recognizer.recognize_google(audio).lower()
    except sr.UnknownValueError:
        speak("I didn't catch that. Can you please repeat?")
        return listen_for_command()
    except sr.RequestError:
        speak("I couldn't request results. Please check your internet connection.")
    
# Function to process voice commands
def process_command(command):
    current_time = datetime.datetime.now()
    if "hello" in command:
        speak("Hello! How can I assist you today?")
    elif "kevin" in command:
        speak("Yes Sir")
    elif "thanks buddy" in command:
        speak("You are Welcome")
    elif"set my status to" in command:
        new_status = command.split("set my status to", 1)[1].strip()
        user_status = new_status
        speak(f"Your status has been updated to: {new_status}")
    elif "open google" in command:
        speak("Opening Google.")
        webbrowser.open("https://www.google.com")
    elif "open youtube" in command:
        speak("Opening YouTube.")
        webbrowser.open("https://www.youtube.com")
    elif "open roblox" in command:
        speak("Opening Roblox.")
        webbrowser.open("https://www.roblox.com")
    elif "make a website" in command:
        speak("Creating a website called Nimicodes.com.")
    elif "open prime video" in command:
        speak("Opening Prime Video.")
        webbrowser.open("https://www.amazon.com/Prime-Video")
    elif "open netflix" in command:
        speak("Opening Netflix.")
        webbrowser.open("https://www.netflix.com")
    elif "call" in command:
        speak("Sure, whom do you want to call?")
        recipient_number = listen_for_command()
        call_on_whatsapp(recipient_number)
    elif "what's the time" in command:
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The current time is {current_time}.")
    elif "play music on youtube" in command:
        speak("Sure, what music would you like to listen to on YouTube?")
        music_query = listen_for_command()
        play_music_on_youtube(music_query)
    elif "send message on whatsapp" in command:
        speak("Sure, whom do you want to send a message to on WhatsApp?")
        recipient_name = listen_for_command()
        speak(f"What message would you like to send to {recipient_name} on WhatsApp?")
        message = listen_for_command()
        send_whatsapp_message(recipient_name, message)

    elif "open safari" in command:
        speak("Opening Safari.")
        # Add code to open Safari here
    elif "open app store" in command:
        speak("Opening the App Store.")
        # Add code to open the App Store here
    elif "open settings" in command:
        speak("Opening Settings.")
        # Add code to open device settings here
    elif "tell a joke" in command:
        joke = get_random_joke()
        speak("Here's a joke for you: " + joke)
    elif "search on Wikipedia" in command:
        speak("What would you like to search for on Wikipedia?")
        query = listen_for_command()
        wikipedia_result = search_wikipedia(query)
        if wikipedia_result:
            speak("Here's what I found on Wikipedia:")
            speak(wikipedia_result)
        else:
            speak("I couldn't find information on that topic.")
    elif "i want to ask you a question" in command:
        speak("Sure, go ahead and ask me a question.")
        question = listen_for_command()
        answer = ask_question(question)
        speak("Here's the answer: " + answer)
    elif "search" in command:
        speak("What would you like to search for?")
        query = listen_for_command()
        search(query)
    elif "who is" in command:
        person = command.split("who is", 1)[1].strip()
        answer = wikipedia_summary(person)
        speak("Here's what I found about " + person + ": " + answer)
    elif "what are" in command:
        query = command.split("what are", 1)[1].strip()
        answer = wikipedia_summary(query)
        speak("Here's what I found about why " + query + ": " + answer)
    elif "why are" in command:
        query = command.split("why are", 1)[1].strip()
        answer = wikipedia_summary(query)
        speak("Here's what I found about why " + query + ": " + answer)
    elif "what's my status" in command:
        speak("Your just the man with the plan and i'm very grateful to have you!")
    elif "what is" in command:
        query = command.split("what is", 1)[1].strip()
        answer = wikipedia_summary(query)
        speak("Here's what I found about " + query + ": " + answer)
    elif "how do i" in command:
        query = command.split("how do i", 1)[1].strip()
        answer = wikipedia_summary(query)
    elif "what are my vitals" in command:
        speak("Your vitals are as follows:\n"
              "Heart rate: 75 beats per minute\n"
              "Blood pressure: 120/80\n"
              "Body temperature: 98.6 degrees Fahrenheit")
    else:
        speak("I'm sorry, I don't understand that command.")
    
# Function to search the web using the default web browser
def search(query):
    try:
        search_url = f"https://www.google.com/search?q={query}"
        webbrowser.open(search_url)
        speak(f"Here are the search results for {query}.")
    except Exception as e:
        print("Error searching:", e)
        speak("I encountered an error while searching. Please try again later.")
 # ...

# Function to play music on YouTube
def play_music_on_youtube(query):
    try:
        # Construct the YouTube search URL
        search_url = f"https://www.youtube.com/results?search_query={query}"
        webbrowser.open(search_url)
        speak(f"Playing music on youTube for {query}.")
    except Exception as e:
        print("Error playing music on youTube:", e)
        speak("I encountered an error while playing music on youTube. Please try again later.")
# ...

# Function to send a WhatsApp message
def send_whatsapp_message(recipient_name, message):
    try:
        # Use pywhatkit to send the WhatsApp message
        # Replace 'your_country_code' with your country code (e.g., +1 for the USA)
        # and 'your_whatsapp_number' with your WhatsApp number
        pywhatkit.sendwhatmsg(f"+2349070067842", message, 0, 0)
        speak(f"Message sent to {recipient_name} on WhatsApp.")
    except Exception as e:
        print("Error sending WhatsApp message:", e)
        speak("I encountered an error while sending the WhatsApp message. Please try again later.")

# Function to call someone on WhatsApp
def call_on_whatsapp(recipient_number):
    try:
        # Use pywhatkit to make a WhatsApp call
        # Replace 'your_country_code' with your country code (e.g., +1 for the USA)
        pywhatkit.call_on_whatsapp(f"+2349070067842", recipient_number)
        speak(f"Calling {recipient_number} on WhatsApp.")
    except Exception as e:
        print("Error making WhatsApp call:", e)
        speak("I encountered an error while making the WhatsApp call. Please try again later.")


# Function to get a random joke from an API
def get_random_joke():
    try:
        response = requests.get("https://official-joke-api.appspot.com/random_joke")
        joke_data = json.loads(response.text)
        setup = joke_data["setup"]
        punchline = joke_data["punchline"]
        return setup + " " + punchline
    except Exception as e:
        print("Error fetching joke:", e)
        return "Why did the chicken cross the road? To get to the other side!"

# Function to fetch a summary from Wikipedia
def wikipedia_summary(query):
    try:
        return wikipedia.summary(query, sentences=2)
    except wikipedia.exceptions.DisambiguationError as e:
        return "There are multiple interpretations. Please specify your question."
    except wikipedia.exceptions.PageError as e:
        return "I couldn't find information on that topic."

# Main loop for listening to voice commands
if __name__ == "__main__":
    speak("Hello Sir! I'm your voice assistant, Kevin. How can I help you today?")
    while True:
        command = listen_for_command()
        print("You said:", command)
        process_command(command)
