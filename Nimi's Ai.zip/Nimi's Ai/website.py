from flask import Flask

app = Flask(__name__)

# Define a route to display the website content
@app.route('/')
def home():
    return 'Welcome to Nimicodes.com'

if __name__ == '__main__':
    app.run(debug=True)
