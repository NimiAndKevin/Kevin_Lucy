import tkinter as tk
from tkinter import ttk

# Create the main application window
app = tk.Tk()
app.title("Kevin's App")
app.geometry("600x400")  # Set the initial window size

# Apply Bootstrap styling (you need to include Bootstrap CSS)
style = ttk.Style()
style.theme_use('bootstrap')

# Create a black background frame
background_frame = ttk.Frame(app, style='TFrame')
background_frame.place(relwidth=1, relheight=1)

# Create a Bootstrap oval avatar
avatar_label = ttk.Label(background_frame, text="Your Avatar", style='TButton')
avatar_label.place(relx=0.4, rely=0.2, relwidth=0.2, relheight=0.2)

# Create a terminal-like text widget
terminal_text = tk.Text(background_frame, bg='black', fg='white', wrap=tk.WORD)
terminal_text.place(relx=0.1, rely=0.5, relwidth=0.8, relheight=0.4)

# Function to add text to the terminal
def add_to_terminal(text):
    terminal_text.insert(tk.END, text + "\n")
    terminal_text.see(tk.END)

# Example: Add some text to the terminal
add_to_terminal("Welcome to Kevin's App!")
add_to_terminal("You can use this terminal for interactions.")

# Run the application
app.mainloop()
